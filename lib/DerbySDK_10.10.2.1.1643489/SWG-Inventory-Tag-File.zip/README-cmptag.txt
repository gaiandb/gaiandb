The Derby team at IBM has supplied a component inventory marker file (tagfile) for this version of the IBM Common Component release of Apache Derby.
Products that have adopted the SWG Inventory Tagging proposal and distribute Derby can include this tagfile in their installation tree.


To install the tagfile your installer should follow the installation instructions documented at:
           https://w3-connections.ibm.com/wikis/home/wiki/Readiness%203.0/page/SWG%20Inventory%20Tagging
Tag files will be placed during product and fix install time under the PRODUCT_ROOT/properties/version directory.
